const currentYear = new Date().getFullYear();

export const YearData = [
    {
        id: 0,
        year: currentYear
    },
    {
        id: 1,
        year: currentYear-1
    },
    {
        id: 2,
        year: currentYear-2
    },
    {
        id: 3,
        year: currentYear-3
    },
    {
        id: 4,
        year: currentYear-4
    },
    {
        id: 5,
        year: currentYear-5
    },
    {
        id: 6,
        year:  currentYear-6
    },
    {
        id: 7,
        year:  currentYear-7
    },
    {
        id: 8,
        year:  currentYear-8
    },
    {
        id: 9,
        year:  currentYear-9
    },
    {
        id: 10,
        year:  currentYear-10
    },
    {
        id: 11,
        year:  currentYear-11
    },
    {
        id: 12,
        year:  currentYear-12
    },
    {
        id: 13,
        year:  currentYear-13
    },
    {
        id: 14,
        year:  currentYear-14
    },
    {
        id: 15,
        year:  currentYear-15
    },
    {
        id: 16,
        year:  currentYear-16
    },
    {
        id: 17,
        year:  currentYear-17
    },
    {
        id: 18,
        year:  currentYear-18
    },
    {
        id: 19,
        year: currentYear-19
    },
    {
        id: 20,
        year: currentYear-20
    },
    {
        id: 21,
        year: currentYear-21
    },
    {
        id: 22,
        year: currentYear-22
    },
];